import GraphNexusApp from '@/components/graph-nexus-app';

export default function Home() {
  return (
    <main className="min-h-screen bg-background text-foreground">
      <GraphNexusApp />
    </main>
  );
}
