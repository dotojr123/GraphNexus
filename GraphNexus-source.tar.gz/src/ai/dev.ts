import { config } from 'dotenv';
config();

import '@/ai/flows/learn-from-text.ts';
import '@/ai/flows/consult-with-context.ts';